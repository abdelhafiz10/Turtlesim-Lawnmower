#!/usr/bin/env python
#Abdel Hafiz

import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from turtlesim.srv import TeleportAbsolute
from std_srvs.srv import Empty as EmptyServiceCall
import math
import time

#constant
PI = 3.1415926535897

#Set position
def set_pose(x0,y0):
	clear = rospy.ServiceProxy('clear',EmptyServiceCall)
	teleport = rospy.ServiceProxy('turtle1/teleport_absolute', TeleportAbsolute)
	teleport(x0,y0,0)
	clear()
def poseCallback(pose_message):
	global x, y, yaw
	x = pose_message.x
	y = pose_message.y
	yaw = pose_message.theta

#Movement function
def move(speed,distance):
	global x, y
	
	velocity = Twist()
    	velocity.linear.x = abs(speed)

    	loop_rate = rospy.Rate(10)  # we publish the velocity at 10 Hz (10 times a second)
    	cmd_vel_topic = '/turtle1/cmd_vel'
    	velocity_publisher = rospy.Publisher(cmd_vel_topic, Twist, queue_size=10)	
    	while not rospy.is_shutdown():

        	#Setting the current time for distance calculus
        	t0 = float(rospy.Time.now().to_sec())
        	current_distance = 0

        	#Loop to move the turtle in an specified distance
        	while(current_distance < distance):
        	    #Publish the velocity
        	    velocity_publisher.publish(velocity)
        	    #Takes actual time to velocity calculus
        	    t1=float(rospy.Time.now().to_sec())
        	    #Calculates distancePoseStamped
        	    current_distance= speed*(t1-t0)
		if not (current_distance < distance):
			break
        	#After the loop, stops the robot
        	velocity.linear.x = 0
		velocity.linear.y = 0
        	#Force the robot to stop
        	velocity_publisher.publish(velocity)

def rotate(speed,angle,clockwise):
    velocity = Twist()
    #Converting from angles to radians
    angular_speed = speed*2*PI/360
    relative_angle = angle*2*PI/360

    #We wont use linear components
    velocity.linear.x=0
    velocity.linear.y=0
    velocity.linear.z=0
    velocity.angular.x = 0
    velocity.angular.y = 0

    # Checking if our movement is CW or CCW
    if clockwise:
        velocity.angular.z = -abs(angular_speed)
    else:
        velocity.angular.z = abs(angular_speed)
    # Setting the current time for distance calculus
    t0 = rospy.Time.now().to_sec()
    current_angle = 0

    while(current_angle < relative_angle):
        velocity_publisher.publish(velocity)
        t1 = rospy.Time.now().to_sec()
        current_angle = angular_speed*(t1-t0)

    #Stopping turtle
    velocity.angular.z = 0
    velocity_publisher.publish(velocity)


def lawnmower(x0,y0,a,b):
	set_pose(x0,y0)
	move(1,a)
	
	rotate(90,90,False)
	move(1,b)
	rotate(90,90,False)
	move(1,a)
	rotate(90,90,True)
	move(1,b)
	rotate(90,90,True)
	move(1,a)
	return_angle = 90 + math.degrees(math.atan2(a,2*b))	
	rotate(90,return_angle,True)
	return_distance = math.sqrt((x-x0)**2+(y-y0)**2)
	move(1,return_distance)
	rotate(90,return_angle,False)

if __name__ == '__main__':
    try:
        #Testing our function
        rospy.init_node('turtlesim_lawnmower',anonymous=True)
	loop_rate = rospy.Rate(10)  # we publish the velocity at 10 Hz (10 times a second)
	cmd_vel_topic = '/turtle1/cmd_vel'
	velocity_publisher = rospy.Publisher(cmd_vel_topic, Twist, queue_size=10)
	position_topic = '/turtle1/pose'
	pose_subscriber = rospy.Subscriber(position_topic, Pose, poseCallback)
	time.sleep(2)
	print("Waking up turtlesim!")	
	print('Configure your turtlesim!')
	x0 = input('Enter X origin: ')
	y0 = input('Enter Y origin: ')
        #out of bounds prevention system
        if (x0 >= 0 and y0 >= 0 and x0 <= 11.08 and y0 <= 11.08):

            a = input("Enter lawnmower length (a) :")
            b = input("Enter lawnmower width (b) :")
	    #wall crash prevention system
            if(x0+a >=11.08 or y0+(2*b)>=11.08):
                print('The turtlesim will hit the wall at this range, try another one!')
            else:
                lawnmower(x0,y0,a,b)
        else:
            print('Oh no! The coordinates were out of bounds, try a different one!')
	print("The turtlesim returned home!")	
    except rospy.ROSInterruptException: pass
